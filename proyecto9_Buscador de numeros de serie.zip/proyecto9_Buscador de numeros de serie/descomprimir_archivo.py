import zipfile

mi_zip = zipfile.ZipFile("Proyecto+Dia+9.zip", "r")

# Extraer un archivo específico
# mi_zip.extract("mi_archivo.txt")

# Extraer todos los archivos de mi_zip
mi_zip.extractall()